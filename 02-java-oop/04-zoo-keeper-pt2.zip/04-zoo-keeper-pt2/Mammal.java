public class Mammal {
    public int energyLevel = 100;
    public String name = "";

    public Integer displayEnergy() {
        System.out.println(energyLevel);
        return energyLevel;
    }
}
