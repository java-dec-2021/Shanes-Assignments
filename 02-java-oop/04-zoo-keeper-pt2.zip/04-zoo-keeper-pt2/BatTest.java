public class BatTest {
    public static void main(String[] args) {
        Bat steve = new Bat("Steve");
        steve.displayEnergy();
        steve.attackTown();
        steve.attackTown();
        steve.attackTown();
        steve.eatHumans();
        steve.eatHumans();
        steve.fly();
        steve.fly();
        steve.displayEnergy();
    }
}
