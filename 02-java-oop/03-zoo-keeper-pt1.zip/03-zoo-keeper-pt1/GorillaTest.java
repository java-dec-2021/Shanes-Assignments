public class GorillaTest {
    public static void main(String[] args) {
        Gorilla harold = new Gorilla("Harold");
        harold.throwSomething("Poop");
        harold.throwSomething("Your mom");
        harold.throwSomething("An anvil");
        harold.displayEnergy();
        harold.eatBananas();
        harold.eatBananas();
        harold.displayEnergy();
        harold.climb();
        harold.displayEnergy();
    }
}
