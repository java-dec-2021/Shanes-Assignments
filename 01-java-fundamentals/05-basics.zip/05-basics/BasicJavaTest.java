public class BasicJavaTest {
    public static void main(String[] args) {
        BasicJava tester = new BasicJava();
        // tester.printRange(1,255);
        // tester.printOddRange(1,255);
        // System.out.println(tester.sigma(255).toString());
        // int[] x = { 1, 3, 5, 7, 9, 13 };
        // tester.iterateArray(x);
        // int[] y = { -25, -6, 3, 1, 20 };
        // System.out.println(tester.findMax(y));
    }
}
