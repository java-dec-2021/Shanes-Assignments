import java.util.Arrays;
public class PuzzleJavaTest {
    public static void main(String[] args) {
        PuzzleJava tester = new PuzzleJava();
        // System.out.println(Arrays.toString(tester.getTenRolls()));
        // System.out.println(tester.getRandomLetter());
        System.out.println(tester.generatePassword());
    }
}
